<?php

namespace Mpdf\Exception;

class AssetFetchingException extends \Mpdf\MpdfException
{

}
